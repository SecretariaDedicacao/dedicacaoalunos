<?php

namespace App;

use App\Model;

class Faq extends Model
{
    //
}
